viewzipfile
-----------

Usage:


  unzipfile [filename]

  will unzip the contents of the zipfile [filename]