﻿using System.Reflection;

[assembly: AssemblyTitle("Cmd_ZipInfo")]
[assembly: AssemblyDescription("list detailed information about a ZIP archive")]
[assembly: AssemblyCulture("")]
