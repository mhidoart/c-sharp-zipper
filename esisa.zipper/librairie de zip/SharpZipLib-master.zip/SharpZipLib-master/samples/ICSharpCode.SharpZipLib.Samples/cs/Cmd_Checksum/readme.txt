minigzip
--------

Usage:


  minigzip [filename]

  Will create (or overwrite) a file [filename].gz with the gzipped
  contents of [filename]

  minigzip -d [filename].gz

  Will create (or overwrite) a file [filename] with the gunzipped
  contents of [filename]

  
